$(document).ready(function() {

		$('form').on('submit', function(event){
			var fileExtension = ['zip'];
			if ($("#InputFile").val()=="") {
				alert("You must be insert a file to upload.");
			} else if ($.inArray($("#InputFile").val().split('.').pop().toLowerCase(), fileExtension) == -1) {
				alert("Only formats zip are allowed" );
			} else {
				event.preventDefault();
				var formData = new FormData($('form')[0]);

						$.ajax({
								xhr : function() {
										var xhr = new window.XMLHttpRequest();
										$('#progresstheme').css("display","block");
										xhr.upload.addEventListener('progress', function(e){
												var percent = Math.round((e.loaded / e.total) * 100);
												$('#progressBar').attr('aria-valuenow', percent).css('width', percent + '%').text(percent + '%');
												if (percent==100) {
													$('#progresstheme').fadeOut("slow");
													$('#infoextrak').html("<div class='alert alert-success'><div style='float:left;'>Extracting data ...</div><div class='col-md-offset-3'><img src='Gear-4.5s-26px.gif' id='imginfoextrack' class='img img-responsive text-right'></div></div>");
												}
										});
										return xhr;
								},

								type : 'POST',
								url : 'upload.php',
								data : formData,
								processData : false,
								contentType : false,
								success : function(response){
									$('#infoupload').html("<div class='alert alert-success'><i class='fa fa-check'></i> Sukses Upload</div>");
									setInterval(function(){
										$("#infoextrak").fadeOut("slow");
									},500);
									$('form')[0].reset();
								},
								error : function(response){
										console.log(response);
								}
						});
					}
		});
});

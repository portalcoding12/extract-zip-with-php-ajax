<?php
    if (!empty($_FILES["file_zip"])) {
				$file_zip = $_FILES['file_zip']['tmp_name'];
				$direktori = "upload/";
				$zip = new ZipArchive;
				if ($zip->open($file_zip) === TRUE) {
          // for ($i=0; $i < $zip->numFiles; $i++) {
          //   $fileInfo = $zip->statIndex($i);
          //   // echo "extracting".$fileInfo['name'];
          // }
          $zip->extractTo($direktori);
					$zip->close();
				}
    }
